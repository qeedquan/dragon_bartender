My entry for TINS 2012

Introducing: Old West Railroad Dragon Bartender!

It's a bartender dragon on a train in the old west!

Serve whisky to customers!
Set bandits on fire!

The creative anachronism is, as you may have guessed, that trains back then didn't have diner cars.

Parallax is evident in the cacti in the background, and prime numbers are used to determine when the score multiplier increases and how the customer/bandit spawn rate increases.

Controls:
Up/Down to move the dragon
Z to send a shot glass of whisky
X to send a burst of flame
Spacebar or P to pause

When paused, you can save the game by pressing S
